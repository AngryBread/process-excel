也是cmd运行
python sample.py all src tmp 120

all指所有文件；src是原始数据存储的文件夹；tmp是处理后文件夹目录(分割+左右取值）；120指取值的窗长

python avg_duration.py tmp new

tmp是待处理数据存放的文件夹 ；new是处理后文件的地址；完成了时间戳初始化+求均值

